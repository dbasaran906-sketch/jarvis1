package com.jarvis.app

import android.Manifest
import android.app.KeyguardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.concurrent.thread
import kotlin.math.max

/** Ek özellikler için köprü (JS tarafında JarvisX). Her çağrı id ile sonuç döndürür. */
class Extras(private val act: JarvisActivity) {

    private val vault = Vault(act)
    private var unlockId: String? = null

    private fun js(code: String) {
        act.runOnUiThread { act.web.evaluateJavascript(code, null) }
    }

    private fun result(id: String, ok: Boolean, data: String) {
        js("window.onNativeResult(${JSONObject.quote(id)}, $ok, ${JSONObject.quote(data)})")
    }

    // ---------- İzinler ----------

    @JavascriptInterface
    fun requestPerms(id: String, csv: String) {
        thread {
            val list = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val ok = act.ensurePerms(list.toTypedArray())
            result(id, ok, if (ok) "ok" else "izin verilmedi")
        }
    }

    // ---------- Radar ve durum ----------

    @JavascriptInterface
    fun radar(id: String) {
        thread {
            try {
                result(id, true, Radar.scan(act).toString())
            } catch (e: Exception) {
                result(id, false, e.message ?: "Radar hatası")
            }
        }
    }

    @JavascriptInterface
    fun status(id: String) {
        thread {
            try {
                result(id, true, Tools.deviceStatus(act))
            } catch (e: Exception) {
                result(id, false, e.message ?: "Durum okunamadı")
            }
        }
    }

    // ---------- Medya ----------

    private fun mediaPerms(): Array<String> {
        return if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun thumb(uri: Uri): String? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 700 || o.outHeight / s > 700) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val k = 288f / max(bmp.width, bmp.height)
            val sc = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true) else bmp
            val bos = ByteArrayOutputStream()
            sc.compress(Bitmap.CompressFormat.JPEG, 70, bos)
            Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    /** args: {"from":saniye,"to":saniye,"offset":n,"limit":n} */
    @JavascriptInterface
    fun photos(id: String, args: String) {
        thread {
            try {
                val a = JSONObject(args)
                if (!act.ensurePerms(mediaPerms())) {
                    result(id, false, "Fotoğraflara erişim izni verilmedi.")
                    return@thread
                }
                val from = a.optLong("from", 0)
                val to = a.optLong("to", System.currentTimeMillis() / 1000)
                val offset = a.optInt("offset", 0)
                val limit = a.optInt("limit", 24)
                val col = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val dateCol = MediaStore.Images.Media.DATE_ADDED
                val c = act.contentResolver.query(
                    col,
                    arrayOf(MediaStore.Images.Media._ID, dateCol),
                    "$dateCol >= ? AND $dateCol <= ?",
                    arrayOf(from.toString(), to.toString()),
                    "$dateCol DESC"
                )
                val items = JSONArray()
                var total = 0
                if (c != null) {
                    c.use {
                        total = it.count
                        if (offset < total && it.moveToPosition(offset)) {
                            do {
                                val pid = it.getLong(0)
                                val uri = ContentUris.withAppendedId(col, pid)
                                val b64 = thumb(uri)
                                if (b64 != null) {
                                    val o = JSONObject()
                                    o.put("uri", uri.toString())
                                    o.put("date", it.getLong(1))
                                    o.put("b64", b64)
                                    items.put(o)
                                }
                            } while (items.length() < limit && it.moveToNext())
                        }
                    }
                }
                val out = JSONObject()
                out.put("total", total)
                out.put("items", items)
                result(id, true, out.toString())
            } catch (e: Exception) {
                result(id, false, "Fotoğraflar okunamadı: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun findFiles(id: String, q: String) {
        thread {
            try {
                if (!act.ensurePerms(mediaPerms())) {
                    result(id, false, "Dosya erişim izni verilmedi.")
                    return@thread
                }
                val col = MediaStore.Files.getContentUri("external")
                val c = act.contentResolver.query(
                    col,
                    arrayOf(
                        MediaStore.Files.FileColumns._ID,
                        MediaStore.Files.FileColumns.DISPLAY_NAME,
                        MediaStore.Files.FileColumns.MIME_TYPE,
                        MediaStore.Files.FileColumns.DATE_ADDED
                    ),
                    MediaStore.Files.FileColumns.DISPLAY_NAME + " LIKE ?",
                    arrayOf("%$q%"),
                    MediaStore.Files.FileColumns.DATE_ADDED + " DESC"
                )
                val arr = JSONArray()
                c?.use {
                    while (it.moveToNext() && arr.length() < 40) {
                        val o = JSONObject()
                        o.put("uri", ContentUris.withAppendedId(col, it.getLong(0)).toString())
                        o.put("ad", it.getString(1) ?: "")
                        o.put("tur", it.getString(2) ?: "")
                        o.put("date", it.getLong(3))
                        arr.put(o)
                    }
                }
                result(id, true, arr.toString())
            } catch (e: Exception) {
                result(id, false, "Arama başarısız: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun openUri(uri: String, mime: String) {
        act.runOnUiThread {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Uri.parse(uri), if (mime.isEmpty()) "*/*" else mime)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                act.startActivity(i)
            } catch (e: Exception) {
                // açacak uygulama yok
            }
        }
    }

    // ---------- Şifre kasası (cihazda şifreli, yapay zekaya gitmez) ----------

    private fun store(): JSONObject {
        val s = vault.get("pw_store")
        return if (s.isEmpty()) JSONObject() else try {
            JSONObject(s)
        } catch (e: Exception) {
            JSONObject()
        }
    }

    @JavascriptInterface
    fun vaultList(): String {
        val arr = JSONArray()
        val it = store().keys()
        while (it.hasNext()) arr.put(it.next())
        return arr.toString()
    }

    @JavascriptInterface
    fun vaultSet(name: String, value: String) {
        val s = store()
        s.put(name, value)
        vault.put("pw_store", s.toString())
    }

    @JavascriptInterface
    fun vaultGet(name: String): String = store().optString(name, "")

    @JavascriptInterface
    fun vaultDel(name: String) {
        val s = store()
        s.remove(name)
        vault.put("pw_store", s.toString())
    }

    @JavascriptInterface
    fun unlock(id: String) {
        act.runOnUiThread {
            val km = act.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) {
                result(id, true, "ok")
                return@runOnUiThread
            }
            @Suppress("DEPRECATION")
            val i = km.createConfirmDeviceCredentialIntent("JARVİS kasası", "Şifrelerini görmek için kimliğini doğrula")
            if (i == null) {
                result(id, true, "ok")
            } else {
                unlockId = id
                act.startActivityForResult(i, 78)
            }
        }
    }

    fun onUnlockResult(ok: Boolean) {
        val id = unlockId ?: return
        unlockId = null
        result(id, ok, if (ok) "ok" else "doğrulanamadı")
    }
}
