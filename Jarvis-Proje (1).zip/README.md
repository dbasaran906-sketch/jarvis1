# JARVİS

Kişisel yapay zeka asistanı (Android). Beyin: Claude API.

## Kurulum (3 adım)
1. GitHub'da **herkese açık (public)** yeni bir depo aç.
2. Bu klasörün İÇİNDEKİ her şeyi (`app`, `.github`, `build.gradle.kts` ...) depoya yükle. Web'de "Add file > Upload files" ile sürükle-bırak yeterli. `.github` klasörünün de yüklendiğinden emin ol.
3. Üstteki **Actions** sekmesinde derleme kendiliğinden başlar (5-8 dk). Bitince **Releases** bölümünde `Jarvis.apk` çıkar. Telefona indirip kur.

İlk açılışta ⚙ Ayarlar'dan Claude API anahtarını gir.

## Güncelleme
Yeni sürümde dosyaları depoya yükle, Actions yeni APK'yı Release'e koyar. Uygulamada Ayarlar > Güncelleme > Kontrol et (ya da Jarvis'e "güncelleme var mı" de).

Not: Güncelleme kontrolü için depo herkese açık olmalı.

## v2 (Ağır güncelleme)
Gemini/Claude seçimi, kamera HUD (nesne, mimik/el, çeviri, yüz), radar, medya arama, şifre kasası, canlı çeviri, cihaz durumu, takvim/arama/SMS araçları.
