package com.jarvis.app

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout

/** Bildirime basınca altta açılan Siri benzeri ses balonu. 5 sn sessizlikte kendini kapatır. */
class VoiceActivity : JarvisActivity() {

    override val voiceMode: Boolean = true

    override fun layoutWeb() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.TRANSPARENT)
        root.setOnClickListener { finish() }
        val h = (resources.displayMetrics.heightPixels * 0.58f).toInt()
        root.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h, Gravity.BOTTOM)
        )
        setContentView(root)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        web.evaluateJavascript("window.beginVoice&&window.beginVoice()", null)
    }
}
