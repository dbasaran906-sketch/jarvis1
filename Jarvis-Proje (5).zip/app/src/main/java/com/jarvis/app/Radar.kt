package com.jarvis.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.pow

/** Yakındaki Bluetooth LE cihazlarını ve Wi-Fi ağlarını tarar. */
object Radar {

    private val espNames = listOf("esp32", "esp-", "esp8266", "espressif", "arduino", "nano 33", "hm-10", "hc-05", "hc-06", "jdy-", "bt05", "at-09")
    private val espOui = listOf(
        "24:0a:c4", "30:ae:a4", "24:6f:28", "84:0d:8e", "a4:cf:12", "7c:9e:bd", "3c:71:bf",
        "cc:50:e3", "8c:aa:b5", "ec:62:60", "40:f5:20", "c4:4f:33", "fc:f5:c4", "b4:e6:2d",
        "9c:9c:1f", "ac:67:b2", "e8:68:e7", "34:94:54", "94:b9:7e", "a0:20:a6"
    )

    private fun dist(rssi: Int): Double {
        val d = 10.0.pow((-59.0 - rssi) / 20.0)
        return Math.round(d * 10) / 10.0
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    fun scan(a: JarvisActivity, seconds: Int = 6): JSONObject {
        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) perms.add(Manifest.permission.BLUETOOTH_SCAN)
        perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (!a.ensurePerms(perms.toTypedArray())) {
            throw RuntimeException("Radar için Bluetooth/yakındaki cihazlar ve konum izni gerekli.")
        }

        val ble = JSONArray()
        val seen = HashMap<String, JSONObject>()
        try {
            val bm = a.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val scanner = bm.adapter?.bluetoothLeScanner
            if (scanner != null) {
                val cb = object : ScanCallback() {
                    override fun onScanResult(callbackType: Int, r: ScanResult) {
                        val addr = r.device.address ?: return
                        val rec = r.scanRecord
                        val name = rec?.deviceName ?: ""
                        val lower = name.lowercase(Locale.ROOT)
                        var esp = espNames.any { lower.contains(it) }
                        if (rec != null && rec.getManufacturerSpecificData(0x02E5) != null) esp = true
                        val o = JSONObject()
                        o.put("tur", "BLE")
                        o.put("ad", if (name.isEmpty()) "Bilinmeyen cihaz" else name)
                        o.put("adres", addr)
                        o.put("rssi", r.rssi)
                        o.put("mesafe_m", dist(r.rssi))
                        o.put("esp", esp)
                        synchronized(seen) { seen[addr] = o }
                    }
                }
                scanner.startScan(cb)
                Thread.sleep(seconds * 1000L)
                scanner.stopScan(cb)
            }
        } catch (e: SecurityException) {
            // izin yoksa BLE listesi boş kalır
        }
        synchronized(seen) {
            for (o in seen.values.sortedByDescending { it.getInt("rssi") }) ble.put(o)
        }

        val wifi = JSONArray()
        try {
            val wm = a.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            try {
                wm.startScan()
            } catch (e: Exception) {
                // kısıtlama
            }
            Thread.sleep(1500)
            val list = wm.scanResults
            for (r in list.sortedByDescending { it.level }.take(30)) {
                val bssid = (r.BSSID ?: "").lowercase(Locale.ROOT)
                val ssid = r.SSID ?: ""
                val o = JSONObject()
                o.put("tur", "WIFI")
                o.put("ad", if (ssid.isEmpty()) "Gizli ağ" else ssid)
                o.put("adres", bssid)
                o.put("rssi", r.level)
                o.put("mesafe_m", dist(r.level))
                o.put("esp", espOui.any { bssid.startsWith(it) } || ssid.lowercase(Locale.ROOT).contains("esp"))
                wifi.put(o)
            }
        } catch (e: SecurityException) {
            // geç
        }

        val out = JSONObject()
        out.put("ble", ble)
        out.put("wifi", wifi)
        return out
    }

    /** Yapay zekaya verilecek kısa özet. */
    fun summary(j: JSONObject): String {
        val sb = JSONObject()
        val ble = j.getJSONArray("ble")
        val wifi = j.getJSONArray("wifi")
        val b = JSONArray()
        for (i in 0 until minOf(ble.length(), 20)) {
            val o = ble.getJSONObject(i)
            val x = JSONObject()
            x.put("ad", o.getString("ad"))
            x.put("rssi", o.getInt("rssi"))
            x.put("yaklasik_m", o.getDouble("mesafe_m"))
            x.put("olasi_esp_arduino", o.getBoolean("esp"))
            b.put(x)
        }
        val w = JSONArray()
        for (i in 0 until minOf(wifi.length(), 12)) {
            val o = wifi.getJSONObject(i)
            val x = JSONObject()
            x.put("ad", o.getString("ad"))
            x.put("rssi", o.getInt("rssi"))
            x.put("olasi_esp", o.getBoolean("esp"))
            w.put(x)
        }
        sb.put("bluetooth_cihaz_sayisi", ble.length())
        sb.put("wifi_ag_sayisi", wifi.length())
        sb.put("bluetooth", b)
        sb.put("wifi", w)
        sb.put("not", "Mesafe RSSI'dan tahmindir, kesin değildir. ESP/Arduino tespiti ad ve üretici işaretine dayalı tahmindir.")
        return sb.toString()
    }
}
