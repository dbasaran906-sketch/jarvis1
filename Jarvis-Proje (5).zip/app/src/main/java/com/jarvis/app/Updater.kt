package com.jarvis.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** GitHub Releases üzerinden kendini güncelleyen basit güncelleyici. */
object Updater {
    class Info(val ok: Boolean, val msg: String, val latest: Int, val tag: String, val url: String)

    fun fetch(): Info {
        val slug = BuildConfig.REPO_SLUG
        if (slug.isBlank()) {
            return Info(false, "Depo bilgisi yok. Uygulama GitHub Actions ile derlenmeli.", 0, "", "")
        }
        val body = Tools.httpGet(
            "https://api.github.com/repos/$slug/releases/latest",
            mapOf("Accept" to "application/vnd.github+json")
        )
        val j = JSONObject(body)
        val tag = j.optString("tag_name")
        val num = tag.substringAfterLast('.').filter { it.isDigit() }.toIntOrNull() ?: 0
        var url = ""
        val assets = j.optJSONArray("assets")
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    url = a.optString("browser_download_url")
                }
            }
        }
        return Info(true, "", num, tag, url)
    }

    fun checkText(): String {
        return try {
            val i = fetch()
            if (!i.ok) {
                i.msg
            } else if (i.latest > BuildConfig.VERSION_CODE && i.url.isNotEmpty()) {
                "Yeni sürüm var: ${i.tag} (şu an ${BuildConfig.VERSION_NAME}). Kurmak için install_update aracını çağır."
            } else {
                "Uygulama güncel (${BuildConfig.VERSION_NAME})."
            }
        } catch (e: Exception) {
            "Güncelleme kontrolü başarısız: ${e.message}. Depo herkese açık olmalı."
        }
    }

    fun download(a: Activity, url: String, onProgress: (Int) -> Unit): File {
        val dir = File(a.cacheDir, "updates")
        dir.mkdirs()
        val f = File(dir, "Jarvis.apk")
        if (f.exists()) f.delete()
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        val total = c.contentLengthLong
        c.inputStream.use { ins ->
            f.outputStream().use { out ->
                val buf = ByteArray(65536)
                var done = 0L
                var last = -1
                while (true) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 100 / total).toInt()
                        if (p != last) {
                            last = p
                            onProgress(p)
                        }
                    }
                }
            }
        }
        return f
    }

    fun install(a: Activity, f: File): String {
        if (!a.packageManager.canRequestPackageInstalls()) {
            a.runOnUiThread {
                a.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + a.packageName)
                    )
                )
            }
            return "Önce açılan ekranda 'bu kaynaktan yüklemeye izin ver' ayarını aç, sonra güncellemeyi tekrar iste."
        }
        val uri = FileProvider.getUriForFile(a, a.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        a.runOnUiThread { a.startActivity(i) }
        return "İndirme tamam, kurulum ekranı açıldı."
    }

    fun installLatest(a: Activity): String {
        val i = fetch()
        if (!i.ok) return i.msg
        if (i.latest <= BuildConfig.VERSION_CODE || i.url.isEmpty()) return "Zaten en güncel sürümdesin."
        val f = download(a, i.url) { }
        return install(a, f)
    }
}
