package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** Jarvis'in telefonda çalıştırabildiği araçlar. */
object Tools {

    fun httpGet(url: String, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "Jarvis-Android")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return text
    }

    fun run(a: Activity, name: String, args: JSONObject): String {
        return try {
            when (name) {
                "get_weather" -> weather(args.optString("city", ""))
                "open_app" -> openApp(a, args.optString("name"))
                "call_phone" -> callPhone(a, args.optString("target"))
                "send_whatsapp" -> whatsapp(a, args.optString("target"), args.optString("message"))
                "set_alarm" -> setAlarm(a, args.optInt("hour"), args.optInt("minute"), args.optString("label", "Jarvis"))
                "set_timer" -> setTimer(a, args.optInt("seconds"), args.optString("label", "Jarvis"))
                "check_update" -> Updater.checkText()
                "install_update" -> Updater.installLatest(a)
                else -> "Bilinmeyen araç: $name"
            }
        } catch (e: Exception) {
            "Hata: ${e.message}"
        }
    }

    // ---------- Hava durumu (Open-Meteo, anahtar gerekmez) ----------

    private fun codeText(c: Int): String = when (c) {
        0 -> "Açık"
        1 -> "Çoğunlukla açık"
        2 -> "Parçalı bulutlu"
        3 -> "Kapalı"
        45, 48 -> "Sisli"
        51, 53, 55, 56, 57 -> "Çisenti"
        61, 63, 65, 66, 67 -> "Yağmurlu"
        71, 73, 75, 77 -> "Karlı"
        80, 81, 82 -> "Sağanak yağışlı"
        85, 86 -> "Kar sağanağı"
        95, 96, 99 -> "Gök gürültülü fırtına"
        else -> "Bilinmiyor"
    }

    private fun weather(cityIn: String): String {
        val city = if (cityIn.isBlank()) "İstanbul" else cityIn
        val g = JSONObject(
            httpGet(
                "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(city, "UTF-8") + "&count=1&language=tr"
            )
        )
        val res = g.optJSONArray("results") ?: return "Şehir bulunamadı: $city"
        val p = res.getJSONObject(0)
        val lat = p.getDouble("latitude")
        val lon = p.getDouble("longitude")
        val place = p.optString("name", city)
        val w = JSONObject(
            httpGet(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
                    "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                    "&timezone=auto&forecast_days=3"
            )
        )
        val cur = w.getJSONObject("current")
        val d = w.getJSONObject("daily")
        val days = JSONArray()
        val times = d.getJSONArray("time")
        val mx = d.getJSONArray("temperature_2m_max")
        val mn = d.getJSONArray("temperature_2m_min")
        val rain = d.getJSONArray("precipitation_probability_max")
        for (i in 0 until times.length()) {
            val o = JSONObject()
            o.put("tarih", times.getString(i))
            o.put("en_yuksek", mx.getDouble(i))
            o.put("en_dusuk", mn.getDouble(i))
            o.put("yagis_ihtimali_yuzde", rain.optInt(i))
            days.put(o)
        }
        val out = JSONObject()
        out.put("place", place)
        out.put("temp", cur.getDouble("temperature_2m"))
        out.put("feels", cur.getDouble("apparent_temperature"))
        out.put("humidity", cur.getInt("relative_humidity_2m"))
        out.put("wind_kmh", cur.getDouble("wind_speed_10m"))
        out.put("desc", codeText(cur.getInt("weather_code")))
        out.put("days", days)
        return out.toString()
    }

    // ---------- Uygulama aç ----------

    private fun openApp(a: Activity, name: String): String {
        if (name.isBlank()) return "Uygulama adı boş."
        val pm = a.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val loc = Locale("tr", "TR")
        val want = name.lowercase(loc)
        var bestPkg: String? = null
        var bestLabel = ""
        for (ri in pm.queryIntentActivities(main, 0)) {
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase(loc)
            if (l == want) {
                bestPkg = ri.activityInfo.packageName
                bestLabel = label
                break
            }
            if (bestPkg == null && (l.contains(want) || want.contains(l))) {
                bestPkg = ri.activityInfo.packageName
                bestLabel = label
            }
        }
        if (bestPkg == null) return "'$name' adında bir uygulama bulamadım."
        val li = pm.getLaunchIntentForPackage(bestPkg) ?: return "$bestLabel açılamıyor."
        a.runOnUiThread { a.startActivity(li) }
        return "$bestLabel açıldı."
    }

    // ---------- Rehber / arama / WhatsApp ----------

    private fun findNumber(a: Activity, q: String): String? {
        val digits = q.filter { it.isDigit() || it == '+' }
        if (q.count { it.isDigit() } >= 5) return digits
        if (a.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            a.runOnUiThread { a.requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2) }
            throw RuntimeException("Rehber izni gerekiyor. İzin penceresini açtım, onayladıktan sonra tekrar söyle.")
        }
        val c = a.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$q%"),
            null
        )
        c?.use {
            if (it.moveToFirst()) return it.getString(1)
        }
        return null
    }

    private fun callPhone(a: Activity, target: String): String {
        val num = findNumber(a, target) ?: return "'$target' için rehberde numara bulamadım."
        val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
        a.runOnUiThread { a.startActivity(i) }
        return "Arama ekranı $target için açıldı, arama tuşuna basmak yeterli."
    }

    private fun whatsapp(a: Activity, target: String, message: String): String {
        val raw = findNumber(a, target) ?: return "'$target' için rehberde numara bulamadım."
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = "90" + d.substring(1)
        else if (d.length == 10) d = "90$d"
        val uri = Uri.parse("https://wa.me/$d?text=" + Uri.encode(message))
        a.runOnUiThread { a.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        return "WhatsApp sohbeti mesaj hazır şekilde açıldı. Göndermek için kullanıcının gönder tuşuna basması gerekiyor."
    }

    // ---------- Alarm / zamanlayıcı ----------

    private fun setAlarm(a: Activity, hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.runOnUiThread { a.startActivity(i) }
        return "Alarm %02d:%02d için kuruldu.".format(hour, minute)
    }

    private fun setTimer(a: Activity, seconds: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.runOnUiThread { a.startActivity(i) }
        return "Zamanlayıcı $seconds saniye için kuruldu."
    }
}
