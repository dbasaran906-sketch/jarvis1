package com.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

/** WebView arayüzü ile Android arasındaki köprü (JS tarafında JarvisNative). */
class Bridge(private val act: JarvisActivity) {

    private val vault = Vault(act)
    private val prefs = act.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak: String? = null
    private var recognizer: SpeechRecognizer? = null
    private var lastRms = 0L

    @Volatile
    var awaitingPermission = false

    init {
        tts = TextToSpeech(act.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        js("window.onSpeakStart&&window.onSpeakStart()")
                    }

                    override fun onDone(utteranceId: String?) {
                        js("window.onSpeakEnd&&window.onSpeakEnd()")
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        js("window.onSpeakEnd&&window.onSpeakEnd()")
                    }
                })
                applyVoice()
                val p = pendingSpeak
                if (p != null) {
                    pendingSpeak = null
                    speak(p)
                }
            }
        }
    }

    private fun js(code: String) {
        act.runOnUiThread { act.web.evaluateJavascript(code, null) }
    }

    private fun q(s: String?): String = JSONObject.quote(s ?: "")

    private fun result(id: String, ok: Boolean, data: String) {
        js("window.onNativeResult(${q(id)}, $ok, ${q(data)})")
    }

    // ---------------- Genel ----------------

    @JavascriptInterface
    fun isVoice(): Boolean = act.voiceMode

    @JavascriptInterface
    fun getVersion(): String = BuildConfig.VERSION_NAME

    @JavascriptInterface
    fun setSecret(name: String, value: String) {
        vault.put(name, value)
    }

    @JavascriptInterface
    fun hasSecret(name: String): Boolean = vault.get(name).isNotEmpty()

    @JavascriptInterface
    fun copy(text: String) {
        act.runOnUiThread {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("jarvis", text))
        }
    }

    @JavascriptInterface
    fun paste(): String {
        return try {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(act)?.toString() ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    @JavascriptInterface
    fun closeVoice() {
        act.runOnUiThread { act.finish() }
    }

    // ---------------- Claude ----------------

    @JavascriptInterface
    fun claude(id: String, body: String) {
        thread {
            try {
                val key = vault.get("api_key")
                if (key.isEmpty()) {
                    result(id, false, "API anahtarı kayıtlı değil. Ayarlardan ekle.")
                    return@thread
                }
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 20000
                c.readTimeout = 120000
                c.doOutput = true
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                result(id, code in 200..299, text)
            } catch (e: Exception) {
                result(id, false, "Bağlantı hatası: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun gemini(id: String, model: String, body: String) {
        thread {
            try {
                val key = vault.get("gemini_key")
                if (key.isEmpty()) {
                    result(id, false, "Gemini API anahtarı kayıtlı değil. Ayarlardan ekle.")
                    return@thread
                }
                val url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent"
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 20000
                c.readTimeout = 120000
                c.doOutput = true
                c.setRequestProperty("x-goog-api-key", key)
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                result(id, code in 200..299, text)
            } catch (e: Exception) {
                result(id, false, "Bağlantı hatası: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun geminiModels(id: String) {
        thread {
            try {
                val key = vault.get("gemini_key")
                if (key.isEmpty()) {
                    result(id, false, "Gemini API anahtarı kayıtlı değil.")
                    return@thread
                }
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 20000
                c.readTimeout = 30000
                c.setRequestProperty("x-goog-api-key", key)
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                result(id, code in 200..299, text)
            } catch (e: Exception) {
                result(id, false, "Bağlantı hatası: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun setListenLang(lang: String) {
        prefs.edit().putString("listenLang", lang).apply()
    }

    @JavascriptInterface
    fun tool(id: String, name: String, args: String) {
        thread {
            val out = try {
                Tools.run(act, name, JSONObject(args))
            } catch (e: Exception) {
                "Hata: ${e.message}"
            }
            result(id, true, out)
        }
    }

    // ---------------- Güncelleme ----------------

    @JavascriptInterface
    fun checkUpdate(id: String) {
        thread {
            try {
                val i = Updater.fetch()
                if (!i.ok) {
                    result(id, false, i.msg)
                    return@thread
                }
                val o = JSONObject()
                o.put("current", BuildConfig.VERSION_CODE)
                o.put("latest", i.latest)
                o.put("tag", i.tag)
                o.put("url", i.url)
                o.put("has", i.latest > BuildConfig.VERSION_CODE && i.url.isNotEmpty())
                result(id, true, o.toString())
            } catch (e: Exception) {
                result(id, false, "${e.message} (depo herkese açık mı?)")
            }
        }
    }

    @JavascriptInterface
    fun installUpdate(id: String, url: String) {
        thread {
            try {
                val f = Updater.download(act, url) { p -> js("window.onUpdateProgress&&window.onUpdateProgress($p)") }
                result(id, true, Updater.install(act, f))
            } catch (e: Exception) {
                result(id, false, "İndirme hatası: ${e.message}")
            }
        }
    }

    // ---------------- Ses (TTS) ----------------

    private fun applyVoice() {
        val t = tts ?: return
        try {
            t.setLanguage(Locale.forLanguageTag(prefs.getString("lang", "tr-TR") ?: "tr-TR"))
            val vn = prefs.getString("voice", "") ?: ""
            if (vn.isNotEmpty()) {
                val v = t.voices?.firstOrNull { it.name == vn }
                if (v != null) t.setVoice(v)
            }
            t.setPitch(prefs.getFloat("pitch", 0.9f))
            t.setSpeechRate(prefs.getFloat("rate", 1.0f))
        } catch (e: Exception) {
            // sessizce geç
        }
    }

    @JavascriptInterface
    fun setVoice(lang: String, voice: String, pitch: Double, rate: Double) {
        prefs.edit()
            .putString("lang", lang)
            .putString("voice", voice)
            .putFloat("pitch", pitch.toFloat())
            .putFloat("rate", rate.toFloat())
            .apply()
        applyVoice()
    }

    @JavascriptInterface
    fun listVoices(): String {
        val arr = JSONArray()
        try {
            val vs = tts?.voices
            if (vs != null) {
                for (v in vs.sortedBy { it.name }) {
                    val o = JSONObject()
                    o.put("name", v.name)
                    o.put("locale", v.locale.toLanguageTag())
                    arr.put(o)
                }
            }
        } catch (e: Exception) {
            // boş liste
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun speak(text: String) {
        if (!ttsReady) {
            pendingSpeak = text
            return
        }
        applyVoice()
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    @JavascriptInterface
    fun stopSpeak() {
        pendingSpeak = null
        try {
            tts?.stop()
        } catch (e: Exception) {
            // yok say
        }
    }

    // ---------------- Ses tanıma ----------------

    @JavascriptInterface
    fun listen() {
        act.runOnUiThread {
            if (!SpeechRecognizer.isRecognitionAvailable(act)) {
                js("window.onListenEnd(100)")
                return@runOnUiThread
            }
            if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                awaitingPermission = true
                act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                return@runOnUiThread
            }
            startRecognizer()
        }
    }

    private fun startRecognizer() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(act)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                js("window.onListenReady&&window.onListenReady()")
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                val now = System.currentTimeMillis()
                if (now - lastRms > 70) {
                    lastRms = now
                    js("window.onRms&&window.onRms($rmsdB)")
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                js("window.onListenEnd($error)")
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                js("window.onSpeech(${q(t)}, true)")
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotEmpty()) js("window.onSpeech(${q(t)}, false)")
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        val listenLang = prefs.getString("listenLang", "") ?: ""
        i.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE,
            if (listenLang.isNotEmpty()) listenLang else prefs.getString("lang", "tr-TR")
        )
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.packageName)
        r.startListening(i)
        recognizer = r
    }

    @JavascriptInterface
    fun stopListen() {
        act.runOnUiThread {
            try {
                recognizer?.cancel()
            } catch (e: Exception) {
                // yok say
            }
        }
    }

    fun onPermissionResult(code: Int, granted: Boolean) {
        if (code == 1) {
            awaitingPermission = false
            if (granted) {
                act.runOnUiThread { startRecognizer() }
            } else {
                js("window.onListenEnd(9)")
            }
        }
        if (code == 3 && granted) postNotification()
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            recognizer?.destroy()
        } catch (e: Exception) {
            // yok say
        }
    }

    // ---------------- Bildirim ----------------

    @JavascriptInterface
    fun notif(on: Boolean) {
        if (on) postNotification() else cancelNotification()
    }

    fun postNotification() {
        try {
            val nm = act.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
            )
            val intent = Intent(act, VoiceActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(
                act, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(act, "jarvis")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("JARVİS")
                .setContentText("Dinlemek için dokun")
                .setContentIntent(pi)
                .setOngoing(true)
                .setShowWhen(false)
                .build()
            nm.notify(1, n)
        } catch (e: Exception) {
            // bildirim izni yoksa sessiz geç
        }
    }

    private fun cancelNotification() {
        val nm = act.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(1)
    }
}
